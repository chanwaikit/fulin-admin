// $(document).ready(function(){
  // $(document).find('.asin-card').on("click",function(e){
  //   console.log($(this))
  //   // console.log(e.target)
  // });
// });


var importKeywordsArray = []
var adCompetingNum = ''   //广告竞品数
var competitiveDegree = '' //竞争度
var competingNum = ''; //竞品数
var monthlySearch = '';  //月搜索量
var searchRank = '';  //搜索量排名
var grabTime = '';  //关键词抓取时间
var kw = '';//关键词

$('body').on('change', '#importExcel', function(e) {
  importExcel(e)

});

$('body').on('click', '.asin-card', function() {
  // alert($(this).text())
  // console.log($(this).hasClass("asin-card"))
  console.log()
  if(!$(this).hasClass("selected")){
    $(this).addClass("selected");
  }else{
    $(this).removeClass("selected");
  }
  

});


// 导入xlsx
function importExcel(file) {
  console.log(file)
  // 获取上传的文件对象
  const { files } = file.target;
  // 通过FileReader对象读取文件
  const fileReader = new FileReader();

  fileReader.onload = event => {
    try {
      const { result } = event.target;
      //以二进制流方式读取得到整份excel表格对象
      const workbook = XLSX.read(result, { type: 'binary' });
      let data = []; //存储获取到的数据
      // 遍历每张工作表进行读取（这里默认只读取第一张表）
      for (const sheet in workbook.Sheets) {
        if (workbook.Sheets.hasOwnProperty(sheet)) {
          // 利用 sheet_to_json 方法将 excel 转成 json 数据
          data = data.concat(XLSX.utils.sheet_to_json(workbook.Sheets[sheet]));
          // break; // 如果只取第一张表，就取消注释这行
        }
      }
      console.log(data);
      var keyObject = data[0];
      for (var k in keyObject) {
        console.log(k)
        if(keyObject[k] == '广告竞品数'){
          adCompetingNum = k
        }

        if(keyObject[k] == '关键词'){
          kw = k
        }
        if(keyObject[k] == '竞争度'){
          competitiveDegree = k
        }
        if(keyObject[k] == '竞品数'){
          competingNum = k;
        }
        if(keyObject[k] == '月搜索量'){
          monthlySearch = k
        }
        if(keyObject[k] == '搜索量排名'){
          searchRank = k
        }
        if(keyObject[k] == '关键词抓取时间'){
          grabTime = k;
        }
      }
      for(var i = 1;i<data.length;i++){


        // var adCompetingNum = ''   //广告竞品数
        // var competitiveDegree = '' //竞争度
        // var competingNum = ''; //竞品数
        // var monthlySearch = '';  //月搜索量
        // var searchRank = '';  //搜索量排名
        // var grabTime = '';  //关键词抓取时间
        
        importKeywordsArray.push({
          adCompetingNum:data[i][adCompetingNum],
          competitiveDegree:data[i][competitiveDegree],
          competingNum:data[i][competingNum],
          monthlySearch:data[i][monthlySearch],
          searchRank:data[i][searchRank],
          grabTime:data[i][grabTime],
          kw:data[i][kw],

        })
       
      }
      // importKeywordsArray = data
      console.log(importKeywordsArray)
    } catch (e) {
      // 抛出文件类型错误不正确的相关提示
      console.log('文件类型不正确');
      return;
    }
  };
  // 以二进制方式打开文件
  fileReader.readAsBinaryString(files[0]);

};

async function getHome(keywords,page){
  var country = $('#country').val();
  return  $.get(country + '/s?k='+keywords+'&ref=nb_sb_noss_2'+(page?'&page='+page:''));
}

async function getTop100Html(href){
  return  $.get(href);
}


// $(".asin-card").on("click",function(e){
//   console.log(e)
//   console.log(e.target)

// });
// $(".asin-card").click((e) => {
//   console.log(e)
//   console.log(e.target)
// });


$('#getTop100').click((e) => {
  getTop100();
});

$('#export-table').click((e) => {
  var type = 'xlsx';
  var elt = document.getElementById('keyword-table');
  var wb = XLSX.utils.table_to_book(elt, {sheet: 'Sheet JS'});
  return XLSX.writeFile(wb, (`相关性分析表.` + (type || 'xlsx')));

});





function getAsinList(html){
  var containers = $(html).find('.a-list-item')
  var asinList = []
  for (let i = 0; i < containers.length; i++) {
    var img = $(containers[i]).find('.a-spacing-small img')[0].src
    console.log(i+1,$(containers[i]).find('.a-icon-row .a-icon-alt')[0])
    console.log(i+1,$(containers[i]).find('.a-icon-row .a-icon-alt'))

    var star = $(containers[i]).find('.a-icon-row .a-icon-alt')[0]?$(containers[i]).find('.a-icon-row .a-icon-alt')[0].innerText.split(' ')[0]:0
    var comment = $(containers[i]).find('.a-icon-row .a-size-small')[0]?$(containers[i]).find('.a-icon-row .a-size-small')[0].innerText:0
    var price = $(containers[i]).find('.p13n-sc-price')[0].innerText
    var asin = $(containers[i]).find('.a-row .a-text-normal')[0].href.split('/')[5]
    

    

    asinList.push({
      img:img,
      star:star,
      comment:comment,
      price:price,
      asin:asin
      
    })
    // console.log(asinList)
  }
  return asinList
}
async function getTop100(){
  var  href = 'https://www.amazon.com/gp/bestsellers/beauty/11058261/ref=sr_bs_5_11058261_1'
  var html1 = await getTop100Html(href)
  var asinList1 = getAsinList(html1)
  // var asinList1 = []
  var html2 = await getTop100Html(href+'&pg=2')
  var asinList2 = getAsinList(html2)

  var asinList = asinList1.concat(asinList2)
  console.log(asinList)
  // $('#top100-list').innerHTML = "11"
 
  for (var i = 0;i<asinList.length;i++){
    $("#top100-list").append(`<div data-asin=${asinList[i].asin} class="asin-card">
    <div><h4>${i+1}</h4></div>
    <div><img src=${asinList[i].img}></div>
    <div>asin：${asinList[i].asin}</div>
    <div>星级：${asinList[i].star}</div>
    <div>评论：${asinList[i].comment}</div>
    <div>价格：${asinList[i].price}</div>

     </div>`);
  }
  

}



$('#generate-table').click((e) => {
  $('#keyword-table tbody').empty();

  searchKeyword()
});

async function searchKeyword(){

  // var selectedAsin = [];
  // var selectDoms = $('.selected');


  // for (let i = 0; i < selectDoms.length; i++) {
  //   selectedAsin.push($(selectDoms[i]).attr('data-asin'))
  // }
  // console.log(115,selectedAsin)

  // res.split(/[\s\n]/) || []
  var selectedAsin = $('#asin-input').val().split(/[\n]/)

  // var keywordsArray = $('#keywords-input').val().split(/[\n]/)


  $('#progress').html('0/' + importKeywordsArray.length)

  // console.log(keywordsArray)

  var keywordsList = []

  for (let k = 0; k < importKeywordsArray.length; k++) {
    var num = 0;
    var html = await getHome(importKeywordsArray[k].kw)
    $('#progress').html(k+1+'/' + importKeywordsArray.length)

    var asinArray = [];
    // var allDoms = $(html).find('.s-result-item')
    
    var allDoms = $(html).find('div')
    for (let i = 0; i < allDoms.length; i++) {
      var asin = $(allDoms[i]).attr('data-asin')
      if(asin){
        asinArray.push(asin)
      }
    }


    for (let i = 0; i < asinArray.length; i++) {
      if(selectedAsin.indexOf(asinArray[i])>-1){
        num++;
      }
    }

    keywordsList.push({
      allNum: asinArray.length,
      num:num,
      adCompetingNum:importKeywordsArray[k].adCompetingNum,   //广告竞品数
      competitiveDegree: importKeywordsArray[k].competitiveDegree, //竞争度
      competingNum: importKeywordsArray[k].competingNum, //竞品数
      monthlySearch :importKeywordsArray[k].monthlySearch,  //月搜索量
      searchRank : importKeywordsArray[k].searchRank,  //搜索量排名
      grabTime : importKeywordsArray[k].grabTime,  //关键词抓取时间
      kw : importKeywordsArray[k].kw,//关键词
    })


    
    console.log(150,asinArray)
    $('#keyword-table').find('tbody').append(`<tr>
    <td>${importKeywordsArray[k].kw}</td>
    <td>${num}/${asinArray.length}</td>
    <td>${(num/asinArray.length).toFixed(4)}</td>
    <td>${importKeywordsArray[k].monthlySearch}</td>
    <td>${importKeywordsArray[k].searchRank}</td>
    <td>${importKeywordsArray[k].competingNum}</td>
    <td>${importKeywordsArray[k].adCompetingNum}</td>
    <td>${importKeywordsArray[k].competitiveDegree}</td>
    <td>${importKeywordsArray[k].grabTime}</td>

    </tr>`)

  }

  // console.log(keywordsList)
  // keywordsList = keywordsList.sort((a,b)=>{
  //   return b.num/b.allNum - a.num/a.allNum
  // })
  // console.log(keywordsList)
  // $('#keyword-table').find('tbody').empty();
  // for(var i = 0;i<keywordsList.length;i++){
  //   $('#keyword-table').find('tbody').append(`<tr>
  //   <td>${keywordsList[i].kw}</td>
  //   <td>${keywordsList[i].num}/${keywordsList[i].allNum}</td>
  //   <td>${(keywordsList[i].num/keywordsList[i].allNum).toFixed(4)}</td>


  //   <td>${keywordsList[i].monthlySearch}</td>
  //   <td>${keywordsList[i].searchRank}</td>
  //   <td>${keywordsList[i].competingNum}</td>
  //   <td>${keywordsList[i].adCompetingNum}</td>
  //   <td>${keywordsList[i].competitiveDegree}</td>
  //   <td>${keywordsList[i].grabTime}</td>
  //   </tr>`)
  // }
  
  
}

