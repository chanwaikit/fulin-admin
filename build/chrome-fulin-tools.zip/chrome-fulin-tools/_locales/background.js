
async function getData(keywords,j,pages,i){
  return $.get('https://www.amazon.co.uk/s?k='+keywords[j]+pages[i]+'&ref=nb_sb_noss');
}

async function getAMZData(dataObj){

  var {
    pp,
    keywords,
    keywordsCampaign,
    profile_id,
    sid,
    asin,
    skuName
  } = dataObj;
  var pages = [ '', '&page=2', '&page=3' ];
  var time = new Date()
  const pageName = [ '第一页', '第二页', '第三页' ];
  
  var res = await getKeywordData({profile_id, sid}) ;
  // console.log(res)
  // return false
  var campaignsList = res.list
  for (let j = 0; j < keywords.length; j++) {
    var response = '';
    var sp_sum = null;
    var natural_sum = null;
    var natural_all_sum = null;
    var sp_all_sum = null;

    var sp_sort = null;
    var sp_all_sort = null ;
    var natural_sort =null ;
    var natural_all_sort =null

    var sp_all_page = null;
    var sp_page = null;
    var natural_all_page = null;
    var natural_page  = null;

    for (let i = 0; i < pages.length; i++) {
      var html = await getData(keywords,j,pages,i)

      var adDoms = $(html).find('div[data-component-type="sp-sponsored-result"]')
      var allDomsRes = $(html).find('.s-result-item')
      // var allDoms = $(html).find('.s-result-item')
      var allDoms = allDomsRes.filter((index,ele)=>{
        return !!$(ele).attr('data-asin')
      })
      // console.log(allDoms)

      // return false
      var result = [];
      var naturalResult = [];
      var adAllResult = [];
      var naturalAllResult = [];

      
      for(let i =0;i<allDoms.length ;i++){
        // const isMine = String(allDoms[i].innerHTML).indexOf(asin) > -1;
        const isMine = $(allDoms[i]).attr('data-asin') == asin;
        const isAd = String(allDoms[i].innerHTML).indexOf('Sponsored') > -1
        naturalAllResult.push( //自然 在广告+自然的 位置
          isMine && !isAd  ? 1 : 0
        )
        adAllResult.push(  //广告 在广告+自然的 位置
          isMine && isAd  ? 1 : 0
        )
        if(isAd){ //广告 在总广告的 位置 
          result.push(  
            isMine && isAd  ? 1 : 0
          )

        }
        if(!isAd){
          naturalResult.push(
            isMine && !isAd  ? 1 : 0
          )
        }
      }

      // console.log(result,naturalResult,naturalAllResult,adAllResult)
      
      if (!sp_sort && result.length > 0) { // 当前页有sp广告
        if (result.indexOf(1) > -1) { // 有我们的广告
          // response = `${result.indexOf(1) + 1}/${result.length}`;
          sp_sum = result.length;
          sp_sort = result.indexOf(1) + 1;
          sp_page = i;
        }
      }

      if (!natural_sort && naturalResult.length > 0) { // 当前页有自然位
        if (naturalResult.indexOf(1) > -1) { //
          natural_sum = naturalResult.length;
          natural_sort = naturalResult.indexOf(1) + 1;
          natural_page = i;
        }
      }

      if (!natural_all_sort  && naturalAllResult.length > 0) { // 当前页有自然位,占总的
        if (naturalAllResult.indexOf(1) > -1) { //
          natural_all_sum = naturalAllResult.length;
          natural_all_sort = naturalAllResult.indexOf(1) + 1;
          natural_all_page = i;
        }
      }

      if (!sp_all_sort && adAllResult.length > 0) { // 当前页有自然位
        if (adAllResult.indexOf(1) > -1) { //
          sp_all_sum = adAllResult.length;
          sp_all_sort = adAllResult.indexOf(1) + 1;
          sp_all_page = i;
        }
      }

      // console.log(naturalResult)
      // return false
      if(i === 2){
        // console.log(keywords[j],pageName[i] ,response,new Date());
        // console.log(campaignsList)
        const campaignObj = campaignsList.filter((element)=>{
          // console.log(element.keyword_id,keywordsCampaign[j].keyword_id)
          return element.keyword_id == keywordsCampaign[j].keyword_id
        })[0]



        let data2Api = {};



        const sumObj = {
          sp_sum ,
          natural_sum ,
          sp_all_sum ,
          natural_all_sum ,

          sp_sort ,
          sp_all_sort ,
          natural_sort ,
          natural_all_sort ,
     
          sp_all_page ,
          sp_page ,
          natural_all_page ,
          natural_page  
       }
        // console.log(sumObj)



        if(pp === 'pc'){
          data2Api = {
            sid,
            bid:campaignObj.bid,
            keywords:campaignObj.keyword_text,
            asin,
            name:skuName,

            sp_sum ,
            natural_sum ,
            sp_all_sum ,
            natural_all_sum ,
  
            sp_sort ,
            sp_all_sort ,
            natural_sort ,
            natural_all_sort ,
       
            sp_all_page ,
            sp_page ,
            natural_all_page ,
            natural_page  
          }
        }else{
          data2Api = {
            sid,
            bid:campaignObj.bid,
            keywords:campaignObj.keyword_text,
            asin,
            name:skuName,

            phone_sp_sum:sp_sum ,
            phone_natural_sum:natural_sum ,
            phone_sp_all_sum:sp_all_sum ,
            phone_natural_all_sum:natural_all_sum ,
  
            phone_sp_sort:sp_sort ,
            phone_sp_all_sort:sp_all_sort ,
            phone_natural_sort:natural_sort ,
            phone_natural_all_sort:natural_all_sort ,
       
            phone_sp_all_page:sp_all_page ,
            phone_sp_page:sp_page ,
            phone_natural_all_page:natural_all_page ,
            phone_natural_page:natural_page  
          }
        }
        console.log(data2Api)
        storeAdPosition(pp,data2Api,time)
        return false
        if(sp_sort >1 || sp_page != 0){ //页码不在第一页 或者 广告位不是首位 改竞价
          if( Number(campaignObj.bid)){
            const  pBid = Number(campaignObj.bid)+ 0.01;
            const keyword_id = keywordsCampaign[j].keyword_id;
            if(pBid < keywordsCampaign[j].maxBid){
              updatePrice(pBid,keyword_id,profile_id,sid)
            }else{
              updatePrice(keywordsCampaign[j].maxBid,keyword_id,profile_id,sid)

            }

          }
        }else if (sp_sort == 1 && Number(sp_page) === 0){
          const  pBid = Number(campaignObj.bid) - 0.01;
          const keyword_id = keywordsCampaign[j].keyword_id;

          if(pBid > 0.1){
            // if(keyword_id !=  159645413905778 ){
            //   updatePrice(pBid,keyword_id,profile_id,sid)
            // }else if(keyword_id == 159645413905778 && pBid >0.55){
              if(pBid > keywordsCampaign[j].minBid){
                updatePrice(pBid,keyword_id,profile_id,sid)
              }
              else{
                updatePrice(keywordsCampaign[j].minBid,keyword_id,profile_id,sid)
  
              }

          }
        }
        // break;
      }
    }


    //所有都得抓3次 汇总

  }
}

async function updatePrice (pBid,keyword_id,profile_id,sid) {
  await $.ajax({
    type: "POST",    
    url: "http://127.0.0.1:7001/api/lingxing/updatePrice",
    dataType: 'json',
    data:{
      bid:pBid,keyword_id,profile_id,sid
    }
  });
}


async function storeAdPosition (pp,data2Api,time) {
  await $.ajax({
    type: "POST",    
    url: "http://127.0.0.1:7001/api/lingxing/storeAdPosition",
    dataType: 'json',
    data:{
      ...data2Api,
      pp,
      time
    }
  });
}

$('#catch_zx_uk3621').click((e) => {
  const profile_id = '3636252046994699';
  const sid = 120;
  var keywords = [ 'dvd player', 'dvd players for tv', 'multi region dvd player' ];
  var keywordsCampaign = [ {
    keyword_id:"159645413905778",
    campaign_name: "DVD3621-关键词-精准-dvd player",
    minBid:0.5,
    maxBid: 1
  }, {
    keyword_id: "205589343773064",
    campaign_name: "DVD3621-关键词-精准-dvd players for tv",
    minBid:0.5,
    maxBid:0.8
  }, {
    keyword_id: "18173767713600",
    campaign_name: "DVD3621-关键词-精准-multi region dvd player",
    minBid:0.5,
    maxBid:0.8
  } ];


  // setInterval(function(){
    getAMZData({
      asin:'B07Z7YMQYT',
      profile_id, //广告组合id
      sid, //店铺id
      keywords,
      keywordsCampaign,
      pp:'pc',
      skuName:'DVD3621_黑色_英规_ELECTCOM_英国'
    })
  // },60000 *5)
});


$('#catch_lxf_uk3621').click((e) => {
  const profile_id = '1188851816548955';
  const sid = 114;
  var keywords = [ 'dvd player', 'dvd players for tv', 'multi region dvd player' ];
  var keywordsCampaign = [ {
    keyword_id:"30383230141214",
    campaign_name: "DVD3621-关键词-精准-dvd player",
    minBid:0.65,
    maxBid:1
  }, {
    keyword_id: "121094557449794",
    campaign_name: "DVD3621-关键词-精准-dvd players for tv",
    minBid:0.5,
    maxBid:0.8

  }, {
    keyword_id: "59761361808668",
    campaign_name: "DVD3621-关键词-精准-multi region dvd player",
    minBid:0.5,
    maxBid:0.8

  } ];

  // setInterval(function(){
    getAMZData({
      asin:'B07Z7YMQYT',
      profile_id, //广告组合id
      sid, //店铺id
      keywords,
      keywordsCampaign,
      pp:'pc',
      skuName:'DVD3621_黑色_英规_ELECTCOM_英国'
    })
  // },60000*5)
});



$('#test_cors11').click((e) => {
  // setInterval(function(){
    getAMZData('phone')
  // },60000)
});

// async function getKeywordData(data){
//   const a = await $.ajax({
//     type: "POST",    
//     url: "http://127.0.0.1:7001/api/lingxing/getKeyword",
//     dataType: 'json',
//     data
//   });
//   return a
// }


async function getKeywordData(data){
  const a = await $.ajax({
    type: "GET",    
    url: "https://fulintech.lingxing.com/api/ads_keyword/listKeywords?length=1000&sort_field=cost&sort_type=desc&profile_id=1188851816548955&start_date=2021-09-20&end_date=2021-10-10&search_field=keyword_text&search_type=2&sid=114&filter_parent=1&extend_search=[]&req_time_sequence=%2Fapi%2Fads_keyword%2FlistKeywords$$3",
    dataType: 'json',
    // data
  });
  return a
}
