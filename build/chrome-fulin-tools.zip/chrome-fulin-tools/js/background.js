// chrome.webRequest.onBeforeRequest.addListener(details => {
//   console.log("打印一下onBeforeRequest的detail:");
//   console.log(details);}, {urls: ["<all_urls>"]}, ["requestBody"]);


// chrome.webRequest.onSendHeaders.addListener(details => {
//   console.log("打印一下onSendHeaders的detail:");
//   console.log(details);}, {urls: ["<all_urls>"]}, ["requestHeaders","extraHeaders"]);


//   chrome.webRequest.onCompleted.addListener(
//     function(details) {
//       console.log(details)
//     // compute a page hash etc, store it
//     tabToHash[details.tabId] = hash;
//     },
//   {
//     urls: ['*://*/*.pdf'],
//     types: ['main_frame']
//   }
//   );


$('body').on('click', '#startABA', function(e) {
  // $('tr[data-checked=true]')
  // console.log($('tr[data-checked=true]'))
  onStart()
  // getLastDate()
  // generateTable()
});


function getLastDate(){
  var nowdays = new Date();
  var year = nowdays.getFullYear();
  var month = nowdays.getMonth();
  if(month==0){
      month = 12;
      year = year-1;

  }
  if(month<10){
      month = '0'+month;
  }
    
  var myDate = new Date(year,month,0);

  var startDate = year+'-'+month+'-01 00:00:00'; //上个月第一天
  var endDate = year+''+month+''+myDate.getDate()
  return endDate
}

function randomNumber(n){
  //创建26个字母数组
  var arr = ['0','1','2','3','4','5','6','7','8','9'];
  var idvalue ='';
  // var n = 4;//这个值可以改变的，对应的生成多少个字母，根据自己需求所改
  for(var i=0; i<n ; i++){
     idvalue+=arr[Math.floor(Math.random()*10)];
  };
  return idvalue;
}
function randomCoding(n){
  //创建26个字母数组
  var arr = ['0','1','2','3','4','5','6','7','8','9','a','b','c','c','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
  var idvalue ='';
  // var n = 4;//这个值可以改变的，对应的生成多少个字母，根据自己需求所改
  for(var i=0; i<n ; i++){
     idvalue+=arr[Math.floor(Math.random()*36)];
  };
  // console.log(idvalue)
  return idvalue;
}


function generateTable(data){
  // var data = {"payload":{"requestId":"76dcbe89-37d7-437a-bcb8-d29134202d29","viewId":"singleDefaultView","reportId":"searchTermsDetail","reportParts":[{"reportPartId":"searchTermsDetail","columnNames":["department","searchterm","searchfrequencyrank","n1clickedasin","n1clickshare","n1producttitle","n1conversionshare","n2clickedasin","n2clickshare","n2producttitle","n2conversionshare","n3clickedasin","n3clickshare","n3producttitle","n3conversionshare"],"reportRows":[{"recordValues":[{"val":"Amazon.com"},{"val":"dvd player"},{"val":"2,969"},{"val":"B007F9XHAY"},{"val":"22.16%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"22.22%"},{"val":"B007S71NZO"},{"val":"9.03%"},{"val":"Craig Electronics CVD401A Compact HDMI DVD Player with Remote in Black | Compatible with DVD-R/DVD-RW/JPEG/CD-R/CD-R/CD | Progressive Scan | Up-convert to 1080p |"},{"val":"9.39%"},{"val":"B07Z7YMQYT"},{"val":"8.31%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"8.03%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd players for tv"},{"val":"12,037"},{"val":"B007F9XHAY"},{"val":"18.53%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"18.46%"},{"val":"B07Z7YMQYT"},{"val":"16.28%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"15.64%"},{"val":"B07V82TGYJ"},{"val":"8.06%"},{"val":"DVD Player,Foramor HDMI DVD Player for Smart TV Support 1080P Full HD with HDMI Cable Remote Control USB Input Region Free Home DVD Players"},{"val":"10.98%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd players"},{"val":"100,589"},{"val":"B007F9XHAY"},{"val":"28.63%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"31.11%"},{"val":"B07Z7YMQYT"},{"val":"13.81%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"16.67%"},{"val":"B087JF29BN"},{"val":"9.75%"},{"val":"DVD Player for TV All Region Free DVD Player with AV Output and USB Input, Remote Control and AV Cable Included"},{"val":"11.67%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd player hdmi"},{"val":"130,541"},{"val":"B007F9XHAY"},{"val":"29.24%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"31.70%"},{"val":"B007S71NZO"},{"val":"26.86%"},{"val":"Craig Electronics CVD401A Compact HDMI DVD Player with Remote in Black | Compatible with DVD-R/DVD-RW/JPEG/CD-R/CD-R/CD | Progressive Scan | Up-convert to 1080p |"},{"val":"24.51%"},{"val":"B07V82TGYJ"},{"val":"9.04%"},{"val":"DVD Player,Foramor HDMI DVD Player for Smart TV Support 1080P Full HD with HDMI Cable Remote Control USB Input Region Free Home DVD Players"},{"val":"10.78%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"sony dvd player"},{"val":"152,390"},{"val":"B007F9XHAY"},{"val":"33.49%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"36.21%"},{"val":"B007F9XHBI"},{"val":"31.88%"},{"val":"Sony DVPSR210P DVD Player"},{"val":"36.55%"},{"val":"B01I5QZN8E"},{"val":"10.01%"},{"val":"Sony BDP-BX370 Blu-ray Disc Player with built-in Wi-Fi and HDMI cable"},{"val":"6.55%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"hdmi dvd player"},{"val":"245,080"},{"val":"B007S71NZO"},{"val":"34.92%"},{"val":"Craig Electronics CVD401A Compact HDMI DVD Player with Remote in Black | Compatible with DVD-R/DVD-RW/JPEG/CD-R/CD-R/CD | Progressive Scan | Up-convert to 1080p |"},{"val":"26.13%"},{"val":"B007F9XHAY"},{"val":"30.16%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"39.64%"},{"val":"B08DKZW2FH"},{"val":"8.97%"},{"val":"Slim Design DVD player for TV, Ultra-Thin Region Free DVD Player, Colourful HD Pixels with HDMI/ RCA Cable Included, USB Input, Contain Remote Control for DVD Player, Support Playback, PAL/NTSC System"},{"val":"7.21%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd players for tv blu ray and regular"},{"val":"246,378"},{"val":"B07Z7YMQYT"},{"val":"32.90%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"37.50%"},{"val":"B07S42W1BB"},{"val":"13.39%"},{"val":"LG BP175 Blu-Ray DVD Player, with HDMI Port Bundle (Comes with a 6 Foot HDMI Cable)"},{"val":"21.43%"},{"val":"B007F9XHAY"},{"val":"9.03%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"7.14%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd player for tv"},{"val":"246,387"},{"val":"B007F9XHAY"},{"val":"27.90%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"29.81%"},{"val":"B07Z7YMQYT"},{"val":"22.85%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"24.04%"},{"val":"B087JF29BN"},{"val":"9.18%"},{"val":"DVD Player for TV All Region Free DVD Player with AV Output and USB Input, Remote Control and AV Cable Included"},{"val":"5.77%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"samsung dvd player"},{"val":"273,136"},{"val":"B01AQB0Y1C"},{"val":"30.67%"},{"val":"Samsung Blu-ray DVD Disc Player With Built-in Wi-Fi 1080p & Full HD Upconversion, Plays Blu-ray Discs, DVDs & CDs, Plus 6Ft High Speed HDMI Cable, Black Finish"},{"val":"17.39%"},{"val":"B007BYLO4E"},{"val":"15.54%"},{"val":"Samsung DVD-E360 DVD Player (Black)"},{"val":"8.70%"},{"val":"B007F9XHAY"},{"val":"10.22%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"30.43%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd players for tv with hdmi"},{"val":"290,674"},{"val":"B007F9XHAY"},{"val":"40.09%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"40.00%"},{"val":"B007S71NZO"},{"val":"12.20%"},{"val":"Craig Electronics CVD401A Compact HDMI DVD Player with Remote in Black | Compatible with DVD-R/DVD-RW/JPEG/CD-R/CD-R/CD | Progressive Scan | Up-convert to 1080p |"},{"val":"13.75%"},{"val":"B092MKQ6FF"},{"val":"10.02%"},{"val":"WONNIE DVD Player for TV, Home DVD Players with HD/AV/Coaxial Output and USB Input, HD 1080P Supported, Built in PAL/NTSC System All Region Free, HDMI/AV Cable and Remote Control Included"},{"val":"6.25%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd players & recorders"},{"val":"345,308"},{"val":"B07Z7YMQYT"},{"val":"19.17%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"42.86%"},{"val":"B007F9XHAY"},{"val":"16.58%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"0.00%"},{"val":"B092MKQ6FF"},{"val":"7.25%"},{"val":"WONNIE DVD Player for TV, Home DVD Players with HD/AV/Coaxial Output and USB Input, HD 1080P Supported, Built in PAL/NTSC System All Region Free, HDMI/AV Cable and Remote Control Included"},{"val":"14.29%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd-player"},{"val":"371,101"},{"val":"B007F9XHAY"},{"val":"41.99%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"40.74%"},{"val":"B07Z7YMQYT"},{"val":"20.24%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"29.63%"},{"val":"B007F9XHBI"},{"val":"10.57%"},{"val":"Sony DVPSR210P DVD Player"},{"val":"11.11%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"cd dvd player"},{"val":"476,979"},{"val":"B07Z7YMQYT"},{"val":"30.38%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"12.50%"},{"val":"B07MJW5BXZ"},{"val":"20.25%"},{"val":"External DVD Drive, USB 3.0 Portable CD/DVD +/-RW Drive/DVD Player for Laptop CD ROM Burner Compatible with Laptop Desktop PC Windows Linux OS Apple Mac Black"},{"val":"31.25%"},{"val":"B007F9XHAY"},{"val":"16.46%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"25.00%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd player for smart tv"},{"val":"478,442"},{"val":"B007F9XHAY"},{"val":"27.92%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"27.08%"},{"val":"B07Z7YMQYT"},{"val":"25.66%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"29.17%"},{"val":"B07V82TGYJ"},{"val":"21.89%"},{"val":"DVD Player,Foramor HDMI DVD Player for Smart TV Support 1080P Full HD with HDMI Cable Remote Control USB Input Region Free Home DVD Players"},{"val":"33.33%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"sony dvd players for tv"},{"val":"529,989"},{"val":"B007F9XHAY"},{"val":"38.96%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"51.28%"},{"val":"B007F9XHBI"},{"val":"25.97%"},{"val":"Sony DVPSR210P DVD Player"},{"val":"30.77%"},{"val":"B07Z7YMQYT"},{"val":"14.29%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"5.13%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd player with hdmi"},{"val":"541,738"},{"val":"B007F9XHAY"},{"val":"40.00%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"38.78%"},{"val":"B007S71NZO"},{"val":"32.77%"},{"val":"Craig Electronics CVD401A Compact HDMI DVD Player with Remote in Black | Compatible with DVD-R/DVD-RW/JPEG/CD-R/CD-R/CD | Progressive Scan | Up-convert to 1080p |"},{"val":"30.61%"},{"val":"B07X8MSSRQ"},{"val":"7.23%"},{"val":"DVD Player with HDMI AV Output, DVD Player for TV, Contain HD with AV Cable/ Remote Control/ USB Input, All Region Support Home DVD Players, Tojock"},{"val":"16.33%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd player sony"},{"val":"562,666"},{"val":"B007F9XHBI"},{"val":"46.31%"},{"val":"Sony DVPSR210P DVD Player"},{"val":"41.38%"},{"val":"B007F9XHAY"},{"val":"33.99%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"37.93%"},{"val":"B00THLNVY0"},{"val":"5.42%"},{"val":"Sony DVPSR210P DVD Player (Progressive Scan) (Renewed)"},{"val":"6.90%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd player with hdmi connection"},{"val":"648,443"},{"val":"B007F9XHAY"},{"val":"42.41%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"37.21%"},{"val":"B007S71NZO"},{"val":"33.54%"},{"val":"Craig Electronics CVD401A Compact HDMI DVD Player with Remote in Black | Compatible with DVD-R/DVD-RW/JPEG/CD-R/CD-R/CD | Progressive Scan | Up-convert to 1080p |"},
  // {"val":"34.88%"},{"val":"B07RXMS9YL"},{"val":"6.96%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling) & Amazon Basics High-Speed HDMI Cable, 10 Feet, 1-Pack"},{"val":"4.65%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd cd player"},{"val":"741,345"},{"val":"B07Z7YMQYT"},{"val":"37.84%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"45.45%"},{"val":"B007F9XHAY"},{"val":"22.97%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"18.18%"},{"val":"B07MJW5BXZ"},{"val":"13.51%"},{"val":"External DVD Drive, USB 3.0 Portable CD/DVD +/-RW Drive/DVD Player for Laptop CD ROM Burner Compatible with Laptop Desktop PC Windows Linux OS Apple Mac Black"},{"val":"18.18%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"hd dvd player"},{"val":"756,515"},{"val":"B007F9XHAY"},{"val":"40.91%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"66.67%"},{"val":"B08F7FC9NV"},{"val":"28.79%"},{"val":"DVD Player for TV, HD DVD Player with HDMI & AV Cable for Projector, 1080P Full HD CD Player, Disc Player for Video & Media CD - All Region Free - PAL/NTSC Compatible - USB Compatible"},{"val":"0.00%"},{"val":"B08L93WQT6"},{"val":"10.61%"},{"val":"DVD Player, Compact DVD Player for TV with HDMI/AV Outputs, HDMI 2.0 & AV Cable Included, All Region DVD Player Support 1080P Full HD USB Multimedia Player Function for Home, Upgrated Remote Control"},{"val":"0.00%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"sony dvd"},{"val":"864,740"},{"val":"B007F9XHAY"},{"val":"56.92%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"80.00%"},{"val":"B007F9XHBI"},{"val":"36.92%"},{"val":"Sony DVPSR210P DVD Player"},{"val":"20.00%"},{"val":"B07MJM6SBP"},{"val":"3.08%"},{"val":"Sony S3700 Blu-Ray Disc Player with Wi-Fi W/ High-Speed HDMI Cable with Ethernet (Renewed)"},{"val":"0.00%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd player hdmi connection"},{"val":"1,116,591"},{"val":"B007S71NZO"},{"val":"38.20%"},{"val":"Craig Electronics CVD401A Compact HDMI DVD Player with Remote in Black | Compatible with DVD-R/DVD-RW/JPEG/CD-R/CD-R/CD | Progressive Scan | Up-convert to 1080p |"},{"val":"42.11%"},{"val":"B007F9XHAY"},{"val":"35.96%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"26.32%"},{"val":"B07PNMTP1Y"},{"val":"5.62%"},{"val":"Megatek Region-Free DVD Player for TV with HDMI Connection (1080p Full-HD Upscaling), Home CD Player, USB Port, AV/Coaxial Outputs, Solid Metal Case"},{"val":"10.53%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd player portable for home"},{"val":"1,201,025"},{"val":"B07CV9J2VQ"},{"val":"51.92%"},{"val":"DBPOWER 11.5 Portable DVD Player, 5-Hour Built-in Rechargeable Battery, 9 Swivel Screen, Support CD/DVD/SD Card/USB, Remote Control, 1.8 Meter Car Charger, Power Adaptor and Car Headrest (Black)"},{"val":"100.00%"},{"val":"B07S1V2V3F"},{"val":"13.46%"},{"val":"17.5 Portable DVD Player with 15.6 Large HD Screen, 6 Hours Rechargeable Battery, Support USB/SD Card/Sync TV and Multiple Disc Formats, High Volume Speaker,Black"},{"val":"0.00%"},{"val":"B007F9XHAY"},{"val":"7.69%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"0.00%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"best dvd player"},{"val":"1,405,218"},{"val":"B007F9XHAY"},{"val":"83.33%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"75.00%"},{"val":"B00KC0HVTQ"},{"val":"8.33%"},{"val":"Panasonic DVD Player DVD-S700 (Black) Upconvert DVDs to 1080p Detail, Dolby Sound from DVD/CDs View Content Via USB"},{"val":"0.00%"},{"val":"B07Z7YMQYT"},{"val":"8.33%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"25.00%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"hdmi dvd player for smart tv"},{"val":"1,476,059"},{"val":"B007F9XHAY"},{"val":"33.75%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"30.77%"},{"val":"B007S71NZO"},{"val":"27.50%"},{"val":"Craig Electronics CVD401A Compact HDMI DVD Player with Remote in Black | Compatible with DVD-R/DVD-RW/JPEG/CD-R/CD-R/CD | Progressive Scan | Up-convert to 1080p |"},{"val":"23.08%"},{"val":"B07V82TGYJ"},{"val":"8.75%"},{"val":"DVD Player,Foramor HDMI DVD Player for Smart TV Support 1080P Full HD with HDMI Cable Remote Control USB Input Region Free Home DVD Players"},{"val":"23.08%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"dvd/cd player"},{"val":"1,489,701"},{"val":"B07Z7YMQYT"},{"val":"50.00%"},{"val":"DVD Player, CD Players for Home, DVD Players for TV"},{"val":"66.67%"},{"val":"B007F9XHAY"},{"val":"32.61%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"33.33%"},{"val":"B08319XH53"},{"val":"8.70%"},{"val":"Ceihoit Mini DVD Player, DVD CD/Disc Player for TV with HDMI/AV Output, HDMI/AV Cables Included, HD 1080P Supported Built-in PAL/NTSC System USB Input"},{"val":"0.00%"}]},{"recordValues":[{"val":"Amazon.com"},{"val":"tv dvd player"},{"val":"1,540,722"},{"val":"B007F9XHAY"},{"val":"50.00%"},{"val":"Sony DVPSR510H DVD Player, with HDMI port (Upscaling)"},{"val":"100.00%"},{"val":"B076TK4NLV"},{"val":"15.00%"},{"val":"Sceptre 32 1080p FHD LED TV-DVD combo HDMI VGA USB MEMC 120, Machine Black"},{"val":"0.00%"},{"val":"B08NTXRH3B"},{"val":"15.00%"},{"val":"Sceptre 19 LED HDTV TV-DVD Combo Machine Black"},{"val":"0.00%"}]}],"rowCount":"27","visible":null,"cachedPart":null}],"postProcessor":null},"profile":null,"error":null}
  // console.log(data)
  // var payload = data.payload || {};
  // var reportParts = payload.reportParts || [];
  // var columnNames = reportParts[0]?reportParts[0].columnNames:[] //表头
  // var reportRows = reportParts[0]?reportParts[0].reportRows:[]  // tbody

  var columnNames = data.columnNames;
  var reportRows = data.reportRows;

  var colHtml = '';
  columnNames.map((ele)=>{
    colHtml+= `<td>${ele}</td>`
  })

  $('#aba-table').find('thead').html(`<tr>
    ${colHtml}
  </tr>`)

  reportRows.map((item)=>{
    var tdHtml = '';
    item.recordValues.map((ele)=>{
      tdHtml+= `<td>${ele.val}</td>`
    })
    $('#aba-table').find('tbody').append(`<tr>
    ${tdHtml}
  </tr>`)
  })


  console.log()

}

async function onStart(){

  console.log(`${randomNumber(1)}${randomCoding(7)}-${randomCoding(4)}-4${randomCoding(3)}-${randomCoding(4)}-${randomCoding(12)}`)
  var requestId = `${randomNumber(1)}${randomCoding(7)}-${randomCoding(4)}-4${randomCoding(3)}-${randomCoding(4)}-${randomCoding(12)}`;
  
  var periodEndDay = getLastDate()


  var selectedAsin = $('#asin-input').val().split(/[\n]/)

  // var keywordsArray = $('#keywords-input').val().split(/[\n]/)


  $('#progress').html('0/' + selectedAsin.length)


  var keywords = []
  var pReportRows = []
  for (let k = 0; k < selectedAsin.length; k++) {
    await setTimeout(async function(){
      $('#progress').html(k + 1+'/' + selectedAsin.length)

      var data = await $.ajax({
        type: "POST",    
        url: "https://sellercentral.amazon.com/analytics/data/dashboard/searchTerms/report/searchTermsDetail?token=gwYar85mB2UqxUDTrTxYpzx9wnLtYPlOIEMdnw5ScaGQAAAAAgAAAABhpKRlcmF3AAAAAFgvVn0er89XIvVkCfE9xQ%3D%3D&vgId=0&mcId=33697256715&product=aba",
        // dataType: 'json',
        headers:{
          // "x-csrf-token": "hL5FIKrmvDkA7ZaWibh01xhDH4p7nh/3RG+FgXGcYmIpAAAAAGGgosEAAAAB",
          "content-type": "application/json",
          "accept": "*/*",
          // "x-amzn-requestid": "c1a22747-c6d8-42ac-ab0f-43d09d9def60"
          // "x-amzn-requestid": "39f6f5d5-3071-41c5-b0a2-4d4d4db3f0dc"
    
    
        },
        
        // contentType:'application/json',
        data:JSON.stringify({
          requestId: requestId,
          reportParameters:[
            {parameterId: "onlyMyAsins", values: [{val: "false"}]},
            {parameterId: "period", values: [{val: "MONTHLY"}]},
            {parameterId: "periodEndDay", values: [{val: periodEndDay}]},
            {parameterId: "searchTerm", values: [{val: ""}]},
            {parameterId: "asinOrProduct", values: [{val: selectedAsin[k].toLowerCase()}]},
            {parameterId: "department", values: [{val: "Amazon.com"}]},
            {parameterId: "limit", values: [{val: "10"}]},
            {parameterId: "dataRefreshDate", values: [{val: "19000101"}]}
          ],
          reportPaginationWithOrderParameter:{
            reportOrders: [{columnId: "searchfrequencyrank", ascending: true}],
            reportPagination: {pageIndex: 0, pageSize: 100}
          }
          
        })
      });
    
      var payload = data.payload || {};
      var reportParts = payload.reportParts || [];
      var columnNames = reportParts[0]?reportParts[0].columnNames:[] //表头
      var reportRows = reportParts[0]?reportParts[0].reportRows:[]  // tbody
    
      // keywords


      reportRows.map((item)=>{
        item.recordValues.map((ele,index)=>{
          if(index == 1  && keywords.indexOf(ele.val) == -1 ){
            keywords.push(ele.val)
            pReportRows = pReportRows.concat(item)
          }
        })
      })



      // generateTable({
      //   columnNames:columnNames,
      //   reportRows:reportRows
      // })

      if(k + 1 == selectedAsin.length){  
        console.log(keywords)
        console.log(columnNames)
        console.log(pReportRows)

        generateTable({
          columnNames:columnNames,
          reportRows:pReportRows
        })
      }
    },5000 * k)
  
    


  }



  // generateTable({
  //   columnNames:pColumnNames,
  //   reportRows:pReportRows
  // })


  

}
